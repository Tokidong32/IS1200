/**
 * @author Viktor Danielsson
 * Viktor Danielsson did the bitmaps for this.
 */
#include "vga_utils.h"

#ifndef main_menu
#define main_menu

int runMenu();

#endif