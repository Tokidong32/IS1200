/**
 * @author Tomas Ålund Viktor Danielsson
 * both worked on this file to create the correct structs for how a players score should be represented in highscores
 */

#ifndef highscore_menu
#define highscore_menu

typedef struct PlayerScore
{
    char choosenLetter[7];
    int playerScore;
}PlayerScore;

typedef struct AllPlayedPlayers
{
   PlayerScore players[6];
   int currentEmptyIndx;
}AllPlayedPlayers;


void getLetterFromArray(char charToFind,int *firstIndexOfChar, int *lastIndexOfChar);

void runHighscoreLetters();

void runHighScoreMenu();
#endif
