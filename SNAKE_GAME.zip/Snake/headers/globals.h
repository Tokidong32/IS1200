/**
 * @author Viktor Danielsson
 * made the code for this file
 */

#include "game_logic.h"
#include "highscore_menu.h"

#ifndef globals
#define globals

extern AllPlayedPlayers players;

extern int player_button;

extern int currentGameScore; 

#endif