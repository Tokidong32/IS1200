Welcome to the snake game produced by Viktor Danielsson and Tomas Ålund.

In order to make the game, open the make_files folder in the terminal and type the make command

Everything will automatically compile into a main.bin file.

To run on the DTEK-board use dtek-run main.bin and make sure that the jtag server is active.

The game is built around a breadboard for buttons so to play the game ensure that  breadboard has 4 buttons which are all connected 
to gpio. Pin gpio_[0],gpio_[1],gpio_[2] and gpio_[3] are connected to:

top button = gpio_[0],
right button = gpio_[1],
bottom button = gpio[2],
left button = gpio[3].

For visuals the game runs using the vga port so connect the dtek board to a compatible screen.

When playing the game you will be presented with a menu where "START GAME" will start a new game by pressing to the right or GPIO_[1] is high. This will start the game and is played with all 4 buttons.

When you have lost you will be presented with a new menu that will allow you to choose a name for your most recent run. This is done by pressing up or down to pick the character and by pressing to the right to select the active character. Pressing to the left will go back one character. When you have picked 6 different characters pressing right one more time will submit your name and bringing you back to the start menu. 